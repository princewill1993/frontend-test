import React from 'react';

// TODO: Implement a component that:
// 1. Has a state to track a list of items
// 2. Has an input field to add new items
// 3. Has a button to add items to the list
// 4. Displays the list of items

const ItemList = () => {
  // Your implementation here
  
  return (
    <div>
      {/* Your JSX here */}
    </div>
  );
};

export default ItemList;