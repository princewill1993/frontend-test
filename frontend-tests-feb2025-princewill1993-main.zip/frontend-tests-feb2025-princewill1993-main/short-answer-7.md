### **2️⃣ Short Answer Questions (2 Questions)**  

7. **Explain the difference between `position: relative` and `position: absolute` in CSS.**

Write your answer here.
Be as detailed as possible.
You can provide a code snippet using markdown format.