### **5️⃣ Advanced Frontend Question** 

11. **In React, what happens during the reconciliation process, and how does the virtual DOM improve performance?** 

Write your answer here.
Be as detailed as possible.
You can provide a code snippet using markdown format.