### **2️⃣ Short Answer Questions (2 Questions)**  

8. **What are the key differences between `var`, `let`, and `const` in JavaScript?**

Write your answer here.
Be as detailed as possible.
You can provide a code snippet using markdown format.